package Archive::BagIt::App;

use MooseX::App;

1;
